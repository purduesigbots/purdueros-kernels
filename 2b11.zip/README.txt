Eclipse project templates goes here; automatically populated by java utility
